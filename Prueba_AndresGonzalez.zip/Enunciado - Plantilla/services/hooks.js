
// Metodo Get para extraer la informacion del JSON
export async function get(URL){

    const response = await fetch(URL);
    return await response.json();
}

// Metodo Post para editar la informacion del JSON
export async function post(URL, data){

    await fetch(URL, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    })
}

// Metodo Put para editar la informacion especifica del JSON
export async function putById(URL, id, data){
    await fetch(`${URL}/${id}`, {
        method: "PUT",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    })
}
// Metodo Delete para borrar informacion del JSON
export async function deleteById(URL, id){
    await fetch(`${URL}/${id}`, {
        method: "DELETE"
    })
}
