const form = document.querySelector("#registerForm");
const btn = document.getElementById("submit");

// Funcion para recoger los datos del form
const getData = () => {
    // creamos un nuevo form con formato key/values
    const data = new FormData(form);
    // recogemos los datos del formulario y los pasamos a un objeto
    const procesedData = Object.fromEntries(data.entries())
    // limpiamos el formulario
    form.reset();
    return procesedData;
};

// Funcion para enviar los datos del form al JSON

const postData = async () => {
    // Usamos una variable para llamar la funcion
    const newUser = getData();

    // Aca tratamos de acceder al servidor
    try{
        await fetch("http://localhost:3000/users", {
            //Luego ponemos el metodo post para que se pueda agregar al json
            method: "POST",
            // Headers apuntando a la aplicacion contenedora que es JSON
            headers: {"Content-Type": "application/json"},
            // Body le especificamos donde va a estar y en el formato
            body: JSON.stringify(newUser)
        });
    } catch(error){
        // En caso tal hay algun error, avisara que hay uno
        alert(error);
    }
};

btn.addEventListener("click", (event) =>{
    event.preventDefault();
    postData();
});



