
const logIn = document.getElementById("loginForm");
const correo= document.getElementById("email");
const contraseña = document.getElementById("password");

logIn.addEventListener("submit", (event) => {
    // evitamos que se recargue la pagina
    event.preventDefault();
    // variables para obtener los valores de correo y contraseña
    const email = correo.value;
    const password = contraseña.value;
    // Accedemos al servidor y verificamos el email y el password
    fetch("http://localhost:3000/users?email" + email + "&password" + password)
        .then((data) => {
            // Si se cumple la condicion ingresara a adminn
            if(data.length > 0) {
                window.location.href = "admin.html";
                
            } 
            // Si no se cumple la condicion avisara que no es correcto
            else{
                alert("Usuario o contraseña incorrectos");
            }
        })
        // En caso tal hay algun error, avisara que hay uno
        .catch((error) => {
            alert("Error")
        });
})
