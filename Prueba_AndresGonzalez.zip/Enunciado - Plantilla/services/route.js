// rutas para importar el json
const {URL_BASE} = "http://localhost:3000"


export const URL_USER = URL_BASE + "/users"
export const URL_VUELOS = URL_BASE + "/flights"
export const URL_RESERVAS = URL_BASE + "/reservations"